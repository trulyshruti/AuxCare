//
//  DetailViewController.h
//  StackScrollView
//
//  Created by Tope on 28/11/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIScrollView *scrollView;

@end
