//
//  DetailThemeiPadController.h
//  mapper
//
//  Created by Tope on 12/01/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SensibleTableView/SensibleTableView.h"

@interface DetailThemeiPadController : SCTableViewController

@end
