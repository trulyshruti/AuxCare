//
//  ViewController.m
//  blogplex
//
//  Created by Tope on 08/11/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ThemeListController.h"
#import "DataLoader.h"
#import "Model.h"
#import "DetailThemeController.h"
#import "ContactViewController.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>


@implementation ThemeListController

@synthesize articles, feedParser, parsedItems, shouldLoadRSS;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


- (void)viewDidLoad
{
    [self.navigationController setNavigationBarHidden:NO];
    
    if(shouldLoadRSS)
    {
        [self loadFromFeed];
    }
    else
    {
        self.articles = [DataLoader loadSampleData];
        [self loadTableData];
    }
    
    
    UIBarButtonItem* backButton = [self createBackBarButtonWithImage:@"back.png"];
    UIBarButtonItem* contactButton = [self createToolBarButtonWithImage:@"add.png"];
    
    [self.navigationItem setLeftBarButtonItem:backButton];
    [self.navigationItem setRightBarButtonItem:contactButton];
    
    
      
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)loadTableData
{
    SCTheme *theme = [SCTheme themeWithPath:@"blogplex-iPhone.sct"];
    
    [self.tableViewModel setTheme:theme];
    
    SCClassDefinition *articleDef = [SCClassDefinition definitionWithClass:[Model class] propertyNames:[NSArray arrayWithObjects:@"title",@"excerpt", nil]];
    
    NSArray* categories = [self getCategories];
    
    for (int i = 0; i < [categories count]; i++) {
        
        NSArray* articlesForSection = [self getArticlesForSection:i];
        
        NSMutableArray* articlesArray = [NSMutableArray arrayWithArray:articlesForSection];
        
        SCArrayOfObjectsSection *arraySection = [SCArrayOfObjectsSection sectionWithHeaderTitle:nil items:articlesArray itemsDefinition:articleDef];
        
        [articleDef propertyDefinitionWithName:@"excerpt"].type = SCPropertyTypeTextView;
        
        arraySection.sectionActions.cellForRowAtIndexPath = ^SCCustomCell*(SCArrayOfItemsSection *itemsSection, NSIndexPath *indexPath)
        {
            NSArray *propertiesArray = [NSArray arrayWithObjects:@"title",@"excerpt", @"theWeekday", @"theDate", nil];
            NSArray *tagsArray = [NSArray arrayWithObjects:@"1", @"2", @"3", @"4", nil];
            
            SCControlCell *customCell = [SCControlCell cellWithText:nil boundObject:nil objectBindings:[NSDictionary dictionaryWithObjects:propertiesArray forKeys:tagsArray] nibName:@"ThemeListCell"];
            
            return customCell;
        };
        
        arraySection.cellActions.willDisplay = ^(SCTableViewCell *cell, NSIndexPath* indexPath)
        {
            [theme styleObject:cell usingThemeStyle:@"articleCell"];
            
        };
        
        NSString* categoryTitle = [[self getCategories] objectAtIndex:i];
        UIView* headerView = [self getHeaderViewWithTitle:categoryTitle];
        
        arraySection.headerView = headerView;
        
        [self.tableViewModel addSection:arraySection];
    }    

}

-(UIBarButtonItem*)createBackBarButtonWithImage:(NSString*)imageName
{
    UIImage* buttonImage = [UIImage imageNamed:imageName];
    
    UIButton* button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    [button setImage:buttonImage forState:UIControlStateNormal];
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem* barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    return barButton;
}

-(UIBarButtonItem*)createToolBarButtonWithImage:(NSString*)imageName
{
    UIImage* buttonImage = [UIImage imageNamed:imageName];
    
    UIButton* button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    [button setImage:buttonImage forState:UIControlStateNormal];
    [button addTarget:self action:@selector(openContactForm) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem* barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    return barButton;
}


-(void)back 
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)openContactForm 
{
    ContactViewController * controller = [[ContactViewController alloc] initWithNibName:@"ContactViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)loadFromFeed
{
    NSURL *feedURL = [NSURL URLWithString:@"http://www.bgr.com/feed/"];
    
	feedParser = [[MWFeedParser alloc] initWithFeedURL:feedURL];
	feedParser.delegate = self;
	feedParser.feedParseType = ParseTypeFull; // Parse feed info and all items
	feedParser.connectionType = ConnectionTypeAsynchronously;
	[feedParser parse];
    
    self.parsedItems = [[NSMutableArray alloc] init];
    self.title = @"Loading feed...";

}

- (void)updateTableWithParsedItems {
    
    articles = [DataLoader loadDataFromFeedItems:parsedItems];
    
	[self loadTableData];
    [self.tableView reloadData];
    self.title = @"Articles";
}

- (void)feedParserDidStart:(MWFeedParser *)parser {
	NSLog(@"Started Parsing: %@", parser.url);
}

- (void)feedParser:(MWFeedParser *)parser didParseFeedInfo:(MWFeedInfo *)info {
	NSLog(@"Parsed Feed Info: “%@”", info.title);
}

- (void)feedParser:(MWFeedParser *)parser didParseFeedItem:(MWFeedItem *)item {
	NSLog(@"Parsed Feed Item: “%@”", item.title);
	if (item) [parsedItems addObject:item];	
}

- (void)feedParserDidFinish:(MWFeedParser *)parser {
	NSLog(@"Finished Parsing%@", (parser.stopped ? @" (Stopped)" : @""));
    [self updateTableWithParsedItems];
}

- (void)feedParser:(MWFeedParser *)parser didFailWithError:(NSError *)error {
	NSLog(@"Finished Parsing With Error: %@", error);
    if (parsedItems.count == 0) {
        self.title = @"Failed"; // Show failed message in title
    } else {
        // Failed but some items parsed, so show and inform of error
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Parsing Incomplete"
                                                         message:@"There was an error during the parsing of this feed. Not all of the feed items could parsed."
                                                        delegate:nil
                                               cancelButtonTitle:@"Dismiss"
                                               otherButtonTitles:nil];
        [alert show];
    }
    
    [self updateTableWithParsedItems];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        return (interfaceOrientation == UIInterfaceOrientationPortrait);
    else
        return YES;
    
}



- (UIView *)getHeaderViewWithTitle:(NSString*)title
{
    UIView* headerView = [[[NSBundle mainBundle] loadNibNamed:@"ListHeaderView" owner:nil options:nil] objectAtIndex:0];
    
    UILabel* titleLabel = (UILabel*)[headerView viewWithTag:1];
    
    [titleLabel setText:title];
    
    return headerView;
}

-(NSArray*)getArticlesForSection:(NSInteger)section
{
    NSArray* keys = [articles allKeys];
    
    NSString* currentKey = [keys objectAtIndex:section];
    
    return [articles objectForKey:currentKey];
}

-(NSArray*)getCategories
{
    return [articles allKeys];
}

@end
