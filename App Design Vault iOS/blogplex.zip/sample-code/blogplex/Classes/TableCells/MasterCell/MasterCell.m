//
//  MasterCell.m
//  blogplex
//
//  Created by Tope on 27/01/2012.
//  Copyright (c) 2012 AppDesignVault. All rights reserved.
//

#import "MasterCell.h"

@implementation MasterCell

@synthesize titleLabel, excerptLabel, dayLabel, dateLabel, bgImageView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
