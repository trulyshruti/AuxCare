//
//  UIImage+iPhone5.h
//  
//
//  Created by Valentin Filip on 9/24/12.
//  Copyright (c) 2012 AppDesignVault. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (iPhone5)

+ (UIImage *)tallImageNamed:(NSString *)name;

@end
