//
//  UINavigationBar+CustomImage.m
//  foody
//
//  Created by Valentin Filip on 9/27/12.
//
//
#import <QuartzCore/QuartzCore.h>
#import "UINavigationBar+CustomImage.h"
#import "Utils.h"

@implementation UINavigationBar (CustomImage)
- (void)drawRect:(CGRect)rect {
    UIImage *image = [UIImage tallImageNamed: @"titleBar.png"];
    if([Utils isVersion6AndBelow])
        [image drawInRect:CGRectMake(0, 0, 320, 44)];
    else
        [image drawInRect:CGRectMake(0, 0, 320, 64)];
}

-(void)willMoveToWindow:(UIWindow *)newWindow{
    [super willMoveToWindow:newWindow];
    [self applyDefaultStyle];
}

- (void)applyDefaultStyle {
    // add the drop shadow
    self.layer.shadowColor = [[UIColor blackColor] CGColor];
    self.layer.shadowOffset = CGSizeMake(0.0, 3);
    self.layer.shadowOpacity = 0.25;
    self.layer.masksToBounds = NO;
    self.layer.shouldRasterize = YES;
}

@end
