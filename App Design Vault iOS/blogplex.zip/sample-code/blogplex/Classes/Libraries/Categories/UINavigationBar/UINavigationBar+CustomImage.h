//
//  UINavigationBar+CustomImage.h
//  foody
//
//  Created by Valentin Filip on 9/27/12.
//
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (CustomImage)

@end
